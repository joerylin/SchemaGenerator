﻿/************************************************************
 *		Table Name ：#TableName#
 *		Description：#TableDescription#
 *		-------------------------------------------------------
 *		--	DROP TABLE #TableName#;
 *		--	SELECT * FROM #TableName#;
 ************************************************************/
#CreateTable# #TableName#
(
#ColumnList#   
)#TableOption#
#ExecutionSign##TableComment##ColumnComment#